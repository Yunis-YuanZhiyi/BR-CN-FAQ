# ACOPOS 6D 入门Demo

- 使用此Demo，了解最基础的6D程序框架。
- 拿来即可调试设备

# 功能特点

- 基本6D运动程序
- 设置Zone，设置载具
- 批量获取所有定子电机温度

# 相关链接

- brhelp发布地址
  - [A06_产品_柔性传输系统 (brhelp.cn)](https://www.brhelp.cn/#/A06_产品_柔性传输系统/000A06_产品_柔性传输系统?id=柔性传输系统acopos-6d)
- AS Help关联文档位置
  - GUID：f5cb2784-9c90-49c7-8bad-248e82eaa6f8

# 项目维护

- 内部维护地址
  - [6D_BasicDemo - Bitbucket (br-automation.com)](https://bitbucket.br-automation.com/projects/FIWW/repos/6d_basicdemo/browse)