Workaround zum Entladen/Laden des Intel Grafiktreibers w�rend des Windows 10 Reboots
------------------------------------------------------------------------------------

GER:

1. Dateien startup.bat und shutdown.bat z.B. in C:\rth ablegen.
2. gpedit.msc aufrufen.
3. Batchfiles beim Shutdown und Startup ausf�hren lassen. Siehe screenshots Startup.png und Shutdown.png

ENG:

1. Copy the files startup.bat and shutdown.bat to C:\rth (create this folder)
2. Run gpedit.msc in Windows
3. Add the scripts as seen in the respective pictures Startup.png and Shutdown.png.

 


