/********************************************************************
 * COPYRIGHT --  
 ********************************************************************
 * Program: FileX
 * File: FileX.c
 * Author: tangq
 * Created: July 30, 2019
 ********************************************************************
 * Implementation of program FileX
 ********************************************************************/

#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
	#include <AsDefault.h>
#endif

void _INIT FileXINIT(void)
{
	/* TODO: Add code here */
	brsstrcpy( &(Handling.Data.Device), &("NETD") );
	brsstrcpy( &(Handling.Data.Parameter), &("/SIP=192.168.1.101 /PROTOCOL=cifs /SHARE=Temp /USER=TQH /PASSWORD=123456" ));
	brsstrcpy( &(Handling.Data.FileName), &("BB.txt") );
	brsstrcpy( &(Handling.Data.WriteData),&("helloworld"));
}

void _CYCLIC FileXCYCLIC(void)
{
	/* TODO: Add code here */
	
	
	switch(Handling.Data.Step)
	{
		case 1:
			//connect to share folder
			Handling.Functionblock.DevLink_0.enable =1;
			Handling.Functionblock.DevLink_0.pDevice = &(Handling.Data.Device);  //(* name of the device, which is needed for other functionblocks *)
			Handling.Functionblock.DevLink_0.pParam = &(Handling.Data.Parameter);  //(* devicepath *)
			DevLink(&Handling.Functionblock.DevLink_0);  //(* call the function*)
			
			if (Handling.Functionblock.DevLink_0.status == 0)  //(* DevLink successful *)
			{
				Handling.Data.Step = 2;  //(* next Step*)
			}
			else if (Handling.Functionblock.DevLink_0.status == ERR_FUB_BUSY )  //(* DevLink not finished -> redo *)			
			{	//(* Busy *)	
			}
			else if(Handling.Functionblock.DevLink_0.status == fiERR_SYSTEM )//(* DevLink error = fiERR_SYSTEM -> detailed info with function "FileIoGetSysError" *)			
			{	
				//(* get detail errorinformation *)
				Error = FileIoGetSysError();	
				Handling.Data.Step = 255;	
			}
			else
			{	
				Handling.Data.Step = 255;
			}
			break;
		
		case 2:
			//check dir
			DInfo.enable      = 1;
			DInfo.pDevice   = &(Handling.Data.Device);
			DInfo.pPath     = 0;

			/* Call FBK */
			DirInfo(&DInfo);

			/* Verify status */
			if (DInfo.status == 0)
			{
				Handling.Data.Step = 10;

				/* Verify number of files found */
				if (DInfo.filenum > 10)
				{
					
				}
			}
			else if (DInfo.status != 65535)
			{
				
				Handling.Data.Step = 0;

				if (DInfo.status == 20799)
				{
					Error = FileIoGetSysError();
				}
			}

			break;
		
		case 10:
			//open file and modify
			Handling.Functionblock.FileOpen_0.enable = 1;
			Handling.Functionblock.FileOpen_0.pDevice = &(Handling.Data.Device);  //(* name of the linked device *)
			Handling.Functionblock.FileOpen_0.pFile =  &(Handling.Data.FileName);  //(* name of the file *)
			Handling.Functionblock.FileOpen_0.mode = fiWRITE_ONLY; //(* write access *)
			FileOpen(&Handling.Functionblock.FileOpen_0);  //(* call the function*)

			if(Handling.Functionblock.FileOpen_0.status == 0 )// (* FileOpen successful *)
			{
				Handling.Data.Step = 21;  //(* next Step*)
			}
			else if(Handling.Functionblock.FileOpen_0.status == ERR_FUB_BUSY)// THEN  (* FileOpen not finished -> redo *)			
			{
			}//(* Busy *)	
			else 
			{		//ELSE  (* Goto Error Step *)
				Handling.Data.Step = 255;
			}
			break;
			
		case 21: //s(* write data into file *)
			Handling.Functionblock.FileWrite_0.enable = 1;
			Handling.Functionblock.FileWrite_0.ident = Handling.Functionblock.FileOpen_0.ident;
			Handling.Functionblock.FileWrite_0.offset = 0; //(* start at the beginning of the file *)
			Handling.Functionblock.FileWrite_0.pSrc = &(Handling.Data.WriteData);
			Handling.Functionblock.FileWrite_0.len = brsstrlen( &(Handling.Data.WriteData) );
			FileWrite(&Handling.Functionblock.FileWrite_0);  //(* call the function*)

			if( Handling.Functionblock.FileWrite_0.status == 0)// THEN  (* FileWrite successful *)
			{
				Handling.Data.Step = 22;  //(* next Step*)
			}
			else if( Handling.Functionblock.FileWrite_0.status == ERR_FUB_BUSY)// THEN  (* FileWrite not finished -> redo *)			
			{
				//(* Busy *)
			}
			else 
			{
				Handling.Data.Step = 255;
				//ELSE  (* Goto Error Step *)
			}
			break;
		
		case 22:	 //(* close file, because of limited number of available file handles on the system *)
			Handling.Functionblock.FileClose_0.enable = 1;
			Handling.Functionblock.FileClose_0.ident = Handling.Functionblock.FileOpen_0.ident; //(* ident for FileCreate-functionblock*)
			FileClose(&Handling.Functionblock.FileClose_0);  //(* call the function*)
			
			if( Handling.Functionblock.FileClose_0.status == 0 )//THEN  (* FileClose successful *)
			{
				Handling.Data.Step = 200;  //(* next Step*)
				//Handling.Command.bWriteFile := 0;  (* clear command *)
			}
			else if( Handling.Functionblock.FileClose_0.status == ERR_FUB_BUSY)// THEN  (* FileClose not finished -> redo *)			
			{
				//(* Busy *)
			}
			else
			{
				//ELSE  (* Goto Error Step *)
				Handling.Data.Step = 255;
			}
			break;
		
		
		case 200:
			Handling.Functionblock.DevUnlink_0.enable =1;
			Handling.Functionblock.DevUnlink_0.handle = Handling.Functionblock.DevLink_0.handle;
			DevUnlink(&Handling.Functionblock.DevUnlink_0);
			if(Handling.Functionblock.DevUnlink_0.status == ERR_OK)
			{
				Handling.Data.Step = 0;
			}
			else if(Handling.Functionblock.DevUnlink_0.status == ERR_FUB_BUSY)
			{
				
			}
			else
			{
				Handling.Data.Step = 255;
			}
	}
}
