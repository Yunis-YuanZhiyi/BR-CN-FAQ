
#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
#include <AsDefault.h>
#endif


void _CYCLIC ProgramCyclic(void)
{
	crane(&crane1);
	
	craneView_0 .InstRef = crane1.InstRef;
	
	craneView(&craneView_0 );
}
