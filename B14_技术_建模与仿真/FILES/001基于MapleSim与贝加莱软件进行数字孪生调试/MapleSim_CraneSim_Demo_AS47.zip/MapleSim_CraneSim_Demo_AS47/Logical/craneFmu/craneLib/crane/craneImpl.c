/********************************************************************
 * COPYRIGHT -- Bernecker + Rainer
 ********************************************************************

 ********************************************************************
 * Basic fmu/fub implementation
 ********************************************************************/


#include <bur/plctypes.h>
#include <sys_lib.h>
#include <fmi2Functions.h>

#ifdef __cplusplus
	extern "C"
	{
#endif
#include "craneLib.h"
#ifdef __cplusplus
	};
#endif

/**********************************************************************/
/* FUB interface declarations */
#define  FMU_Enable 			fubInstance->Enable

#define  FMU_Instance 			fubInstance->Internal.Fmi2.Instance
#define  FMU_Enabled 			fubInstance->Internal.Fmi2.Enabled
#define  FMU_Error 			fubInstance->Internal.Fmi2.Error
#define  FMU_EndTime    		fubInstance->Internal.Fmi2.EndTime
#define  FMU_StartTime    		fubInstance->Internal.Fmi2.StartTime
#define  FMU_CurrentTime   		fubInstance->Internal.Fmi2.CurrentTime
#define  FMU_StepSize    		fubInstance->Internal.Fmi2.StepSize
#define  FMU_Callbacks   		fubInstance->Internal.Fmi2.Callbacks


/**********************************************************************/
/* Method delcarations */
void crane_fmuLogger(fmi2Component c, fmi2String instanceName, fmi2Status status, fmi2String category, fmi2String message, ...);
void* crane_AllocateMemory(UDINT numElements, UDINT elementSize);
void crane_FreeMemory(void* pMemory);


void crane_initFMU(struct crane* fubInstance);

void crane_initFMUCallbacks(struct crane* fubInstance);
void crane_initFMUCoSimParameters(struct crane* fubInstance);

void crane_stepFMU(struct crane* fubInstance);
void crane_resetFMU (struct crane* fubInstance);

void crane_copyOutputsFromFmu(struct crane* fubInstance);
void crane_copyInputsToFmu(struct crane* fubInstance);
void crane_clearFmuOutputs(struct crane* fubInstance);


/**********************************************************************/
/* FUB implementation */
void crane(struct crane* fubInstance)
{
	crane_ProcessFmuState(fubInstance);	
}

/* Processes the fmu states */
void  crane_ProcessFmuState(struct crane* fubInstance)
{
	if (FMU_Enable)
	{
		if (!FMU_Enabled)
		{
			crane_initFMU(fubInstance);
			FMU_Enabled = fmi2True;
		}

		if(FMU_Error == 0)
		{
			crane_stepFMU(fubInstance);
		}			
	}else
	{
		if (FMU_Enabled)
		{
			crane_resetFMU(fubInstance);
			FMU_Enabled = fmi2False;
		}		
	}
	fubInstance->InstRef = &(fubInstance->Internal);
}

/* Initialises the FMU */
void crane_initFMU(struct crane* fubInstance)
{	
	fmi2Status retStatus = fmi2OK;
	FMU_Error = 0;
	
	crane_initFMUCoSimParameters(fubInstance);
	
	crane_initFMUCallbacks(fubInstance);

	FMU_Instance = crane_fmi2Instantiate("crane",fmi2CoSimulation,"{b4638740-112e-84b0-0dc9-587e46fdca9c}",NULL,&FMU_Callbacks,fmi2False,fmi2False);
	
	if (!FMU_Instance)
	{
		FMU_Error = fmi2True;
	}else
	{
		retStatus = crane_fmi2SetupExperiment(FMU_Instance,0 ,0.0, FMU_StartTime, 0, FMU_EndTime);

		if (retStatus > fmi2Warning) 
		{
			FMU_Error = fmi2True;
			return;
		}

		retStatus = crane_fmi2EnterInitializationMode(FMU_Instance);
		if (retStatus > fmi2Warning) 
		{
			FMU_Error = fmi2True;
			return;
		}

		retStatus = crane_fmi2ExitInitializationMode(FMU_Instance);
		if (retStatus > fmi2Warning) 
		{
			FMU_Error = fmi2True;
			return;
		}
		
		crane_copyOutputsFromFmu(fubInstance);
	}	
}

/* Initialize CoSimulation parmeters */
void crane_initFMUCoSimParameters(struct crane* fubInstance)
{
	FMU_StartTime = 0.00000000000000000e+00;
	FMU_EndTime = 0.0;
	FMU_StepSize = 4.00000000000000000e-04;
	
	FMU_CurrentTime = 0.0;	
}

/* Initialize FMU callbacks */
void  crane_initFMUCallbacks(struct crane* fubInstance)
{
	FMU_Callbacks.Logger = crane_fmuLogger;
	FMU_Callbacks.AllocateMemory = crane_AllocateMemory;
	FMU_Callbacks.FreeMemory = crane_FreeMemory;	
	FMU_Callbacks.StepFinished = NULL;
	FMU_Callbacks.ComponentEnvironment = NULL;
}

/* Execute FMU steps */
void crane_stepFMU(struct crane* fubInstance)
{
	
	if (FMU_Error == 0)
	{		
		crane_copyInputsToFmu(fubInstance);
		
		fmi2Status retStatus = crane_fmi2DoStep(FMU_Instance, FMU_CurrentTime, FMU_StepSize, fmi2True);

		if(retStatus <= fmi2Warning)
		{
			crane_copyOutputsFromFmu(fubInstance);
		
			FMU_CurrentTime += FMU_StepSize;
		}else
		{
			FMU_Error = fmi2True;
		}	
	}
}


/* Reset the FMU */
void crane_resetFMU (struct crane* fubInstance)
{
	fmi2Status retStatus = crane_fmi2Reset(FMU_Instance);

	if(retStatus <= fmi2Warning)
	{
		crane_clearFmuOutputs(fubInstance);
		FMU_CurrentTime = 0;
	}else
	{
		FMU_Error = fmi2True;
	}
}

/* Log FMU calls */
void crane_fmuLogger(void *componentEnvironment, fmi2String instanceName, fmi2Status status, fmi2String category, fmi2String message, ...) 
{
	
}

/* Allocate memory */
void* crane_AllocateMemory(UDINT numElements, UDINT elementSize)
{
	void* address;
	UDINT status = 0;
	
	status = TMP_alloc(numElements * elementSize, &address);
	
	
	if (status == 0)
	{
		return address;
	}
	else
	{
		return NULL;
	}
}

/* Free allocated memory */
void crane_FreeMemory(void* pMemory)
{
	free(pMemory);
}

/* Clear the output values of the FMU */
void crane_clearFmuOutputs(struct crane* fubInstance)
{
	/*Clear fmu output motor_torque*/
	fubInstance->motor_torque = 0.0;
	
}


/* Copy output values from the FMU */
void crane_copyOutputsFromFmu(struct crane* fubInstance)
{
	fmi2ValueReference valueReference;
	fmi2Status retStatus = fmi2OK;

	/*Copy fmu output motor_torque to motor_torque */
	valueReference = 11;
	fmi2Real motor_torque;
	retStatus = crane_fmi2GetReal(FMU_Instance, &valueReference, 1, &motor_torque);

	if(retStatus <= fmi2Warning)
	{
		fubInstance->motor_torque = motor_torque;
	}else
	{
		FMU_Error = fmi2True;
		return;
	}	
}

/* Copy input values to the FMU */
void crane_copyInputsToFmu(struct crane* fubInstance)
{
	fmi2ValueReference valueReference;
	fmi2Status retStatus = fmi2OK;

	/*Copy fmu input vel_trolley to vel_trolley */
	valueReference = 13;
	fmi2Real vel_trolley;
	vel_trolley = fubInstance->vel_trolley;
	retStatus = crane_fmi2SetReal(FMU_Instance, &valueReference, 1, &vel_trolley);
	if(retStatus > fmi2Warning)
	{
		FMU_Error = fmi2True;
		return;
	}	
}



